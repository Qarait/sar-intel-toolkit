# SAR-INTEL TOOLKIT — MVP v0.3

Simulation-first mission intelligence toolkit for search-and-rescue drones.

This version keeps the original v0.1/v0.2 pipeline and adds telemetry log replay:

1. Generates a search grid from a bounding box.
2. Runs person detection on video frames using a pretrained detector.
3. Simulates drone telemetry along the generated path, or replays timestamped telemetry from CSV.
4. Fuses detection + telemetry into JSON alerts.
5. Links repeated frame-level detections into confirmed person tracks.
6. Supports `telemetry.mode: replay` for timestamped drone telemetry logs.

## Run

Ultralytics-first config:

```bash
pip install -r requirements.txt
python main.py --config config.yaml
```

Offline-safe config:

```bash
pip install -r requirements.txt
python main.py --config config.offline.yaml
```

## Inputs

- `config.yaml` or `config.offline.yaml`
- `sample_data/video.mp4`

## Outputs

- `sample_data/path.json` — generated search waypoints
- `output/alerts.json` — one alert per detected person per processed frame
- `output/tracks.json` — deduplicated confirmed person tracks

## Alert Output

`output/alerts.json` remains compatible with v0.1. It keeps the original alert schema by default:

```json
[
  {
    "timestamp": "2026-04-18T15:00:01Z",
    "lat": 43.6489098,
    "lon": -79.3807224,
    "confidence": 0.9394,
    "type": "possible_person"
  }
]
```

Fields:

- `timestamp`: UTC time of the alert, computed from `video.start_time_utc + frame_idx / fps`
- `lat`, `lon`: estimated person location using the MVP nadir-camera projection
- `confidence`: detector confidence from the active backend
- `type`: alert class, currently `possible_person`
Optional: set `tracking.include_track_id_in_alerts: true` if you also want each per-frame alert to include its assigned `track_id`.

## Track Output

`output/tracks.json` summarizes repeated detections into deduplicated person tracks:

```json
[
  {
    "track_id": 1,
    "type": "possible_person_track",
    "first_seen": "2026-04-18T15:00:01Z",
    "last_seen": "2026-04-18T15:00:08Z",
    "first_frame": 25,
    "last_frame": 200,
    "hits": 88,
    "lat": 43.6489101,
    "lon": -79.380723,
    "max_confidence": 0.9394,
    "mean_confidence": 0.8841,
    "representative_bbox": [1400.22, 530.14, 1648.61, 1180.75]
  }
]
```

Tracking is deliberately simple and dependency-free. It associates detections across frames using bounding-box IoU plus approximate geotag proximity, then emits only tracks with at least `tracking.min_hits` detections.



## Telemetry Replay

v0.3 adds optional telemetry log replay. Simulated telemetry remains the default, but the pipeline can now fuse detections with timestamped drone states from a CSV file.

```yaml
telemetry:
  mode: simulated   # simulated | replay
  replay_path: sample_data/telemetry.csv
```

For replay mode, use:

```yaml
telemetry:
  mode: replay
  replay_path: sample_data/telemetry.csv
```

Run the replay demo config:

```bash
python main.py --config config.replay.yaml
```

Expected CSV columns:

```csv
timestamp,lat,lon,altitude_m,yaw_deg,pitch_deg,roll_deg
2026-04-17T19:30:00.000Z,43.649000,-79.381000,60.0,90.0,0.0,0.0
2026-04-17T19:30:02.000Z,43.649000,-79.380800,60.0,90.0,0.0,0.0
```

Replay behavior:

- Rows are parsed as UTC timestamps and sorted by time.
- Drone `lat`, `lon`, `altitude_m`, `yaw_deg`, `pitch_deg`, and `roll_deg` are linearly interpolated between rows.
- Requests before the first row or after the last row are clamped to the nearest available telemetry state.
- `altitude_m` from replay telemetry is used for the current flat-ground geotag projection.
- `yaw_deg`, `pitch_deg`, and `roll_deg` are parsed and preserved for future pose-aware geotagging, but v0.3 does not yet use them in the projection model.

## Tracking Config

```yaml
tracking:
  enabled: true
  include_track_id_in_alerts: false
  iou_threshold: 0.25
  max_frame_gap: 10
  max_position_distance_m: 12.0
  min_hits: 3
```

Tuning guidance:

- Increase `min_hits` to reduce false tracks.
- Increase `max_frame_gap` if detections flicker between frames.
- Lower `iou_threshold` if bounding boxes jitter heavily.
- Lower `max_position_distance_m` if nearby people are being merged.

## Notes

- `config.yaml` uses a pretrained Ultralytics detect model.
- `config.offline.yaml` forces OpenCV HOG person detection so the pipeline can run without downloading model weights.
- The geotagging step is intentionally approximate: it assumes a nadir-looking camera, flat ground, and no terrain model.
- v0.2 does not change the detector, telemetry simulator, or geotag projection model; it only adds a deduplication layer after detections are geotagged.
